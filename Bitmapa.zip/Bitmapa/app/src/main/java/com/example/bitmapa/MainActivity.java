package com.example.bitmapa;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int mode = 0;
    private int shape = 0;
    private boolean isSelected = false;
    private Button kreuj, czysc, linie, elipse, kwadrat;
    private ImageView imageView;
    private Bitmap bitmap;
    private Canvas canvas;
    private Paint paint;
    private Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        kreuj = findViewById(R.id.button1);
        czysc = findViewById(R.id.button2);
        linie = findViewById(R.id.button3);
        elipse = findViewById(R.id.button4);
        kwadrat = findViewById(R.id.button5);

        random = new Random();
        bitmap = Bitmap.createBitmap(800, 1200, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        paint = new Paint();
        paint.setStrokeWidth(5);



        imageView.setImageBitmap(bitmap);

        kreuj.setOnClickListener(v -> {
            mode = 1;
            enableButtons(true);
            isSelected = false;
        });

        czysc.setOnClickListener(v -> {
            clear();
            enableButtons(true);
            isSelected = false;
        });

        linie.setOnClickListener(v -> {
            if (mode == 1 && (!isSelected || shape == 3)) {
                shape = 3;
                isSelected = true;
                rysuj();
                enableButtons(false);
            }
        });


        elipse.setOnClickListener(v -> {
            if (mode == 1 && (!isSelected || shape == 4)) {
                shape = 4;
                isSelected = true;
                rysuj();
                enableButtons(false);
            }
        });


        kwadrat.setOnClickListener(v -> {
            if (mode == 1 && (!isSelected || shape == 5)) {
                shape = 5;
                isSelected = true;
                rysuj();
                enableButtons(false);
            }
        });
    }


    private void enableButtons(boolean enable) {
        if (shape != 3) {
            linie.setEnabled(enable);
        }
        if (shape != 4) {
            elipse.setEnabled(enable);
        }
        if (shape != 5) {
            kwadrat.setEnabled(enable);
        }
    }

    private int getColor() {
        return Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256));
    }

    private void rysuj() {
        for (int i = 0; i < 10; i++) {
            int startX = random.nextInt(bitmap.getWidth());
            int startY = random.nextInt(bitmap.getHeight());
            int endX = random.nextInt(bitmap.getWidth());
            int endY = random.nextInt(bitmap.getHeight());

            paint.setColor(getColor());

            switch (shape) {
                case 3:
                    canvas.drawLine(startX, startY, endX, endY, paint);
                    break;
                case 4:
                    canvas.drawOval(new RectF(startX, startY, endX, endY), paint);
                    break;
                case 5:
                    int side = Math.min(Math.abs(endX - startX), Math.abs(endY - startY));
                    canvas.drawRect(startX, startY, startX + side, startY + side, paint);
                    break;
            }
        }

        imageView.invalidate();
    }

    private void clear() {
        canvas.drawColor(Color.WHITE);
        imageView.invalidate();
    }
}
