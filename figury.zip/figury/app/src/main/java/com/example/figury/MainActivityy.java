package com.example.figury;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivityy extends AppCompatActivity {
    private List<ShapeView> shapes;
    private static final int SHAPE_COUNT = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FrameLayout frameLayout = findViewById(R.id.frameLayout);
        shapes = new ArrayList<>();


        for (int i = 0; i < SHAPE_COUNT; i++) {
            ShapeView shapeView = new ShapeView(this);
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
            );
            shapeView.setLayoutParams(params);
            frameLayout.addView(shapeView);
            shapes.add(shapeView);
        }


        frameLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (ShapeView shape : shapes) {
                    shape.moveShape();
                }
            }
        });
    }
}
