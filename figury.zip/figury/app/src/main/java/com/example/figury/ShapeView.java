package com.example.figury;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import androidx.annotation.NonNull;

import java.util.Random;

public class ShapeView extends View {
    private final Paint paint;
    private final Random random;
    private float x, y;
    private final float radius;
    private static final float MIN_RADIUS = 50;
    private static final float MAX_RADIUS = 150;

    public ShapeView(Context context) {
        super(context);
        paint = new Paint();
        random = new Random();
        radius = MIN_RADIUS + random.nextFloat() * (MAX_RADIUS - MIN_RADIUS);
        x = random.nextFloat() * getWidth();
        y = random.nextFloat() * getHeight();
        paint.setColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(x, y, radius, paint);
    }

    public void moveShape() {
        x = random.nextFloat() * getWidth();
        y = random.nextFloat() * getHeight();
        paint.setColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
        invalidate();
    }
}
