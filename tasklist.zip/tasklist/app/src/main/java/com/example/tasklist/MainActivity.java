package com.example.tasklist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements TasksAdapter.OnTaskListener {
    FloatingActionButton addBtn;
    private TasksAdapter adapter;
    private ArrayList<Tasks> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        arrayList = new ArrayList<>();

        Tasks task1 = new Tasks("zrobić śniadanie", "jajko z bekonem");
        Tasks task2 = new Tasks("zrobić śniadanie", "płatki");
        Tasks task3 = new Tasks("zrobić śniadanie", "parówki");

        arrayList.add(task1);
        arrayList.add(task2);
        arrayList.add(task3);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TasksAdapter(arrayList, this);
        recyclerView.setAdapter(adapter);

        addBtn = findViewById(R.id.addBtn);
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, addActivity.class);
                startActivityForResult(intent, 1);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            String taskName = data.getStringExtra("task_name");
            String taskDesc = data.getStringExtra("task_desc");
            if (taskName != null && taskDesc != null) {
                Tasks newTask = new Tasks(taskName, taskDesc);
                arrayList.add(newTask);
                adapter.notifyDataSetChanged();
            }
        } else if (requestCode == 2 && resultCode == RESULT_OK) {
            String updatedName = data.getStringExtra("updated_name");
            String updatedDesc = data.getStringExtra("updated_desc");
            int position = data.getIntExtra("task_position", -1);

            if (position != -1 && updatedName != null && updatedDesc != null) {
                arrayList.get(position).setTask(updatedName);
                arrayList.get(position).setDesc(updatedDesc);
                adapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onTaskClick(int position) {
        Intent intent = new Intent(MainActivity.this, EditTaskActivity.class);
        intent.putExtra("task_position", position);
        intent.putExtra("task_name", arrayList.get(position).getTask());
        intent.putExtra("task_desc", arrayList.get(position).getDesc());
        startActivityForResult(intent, 2);
    }
}
