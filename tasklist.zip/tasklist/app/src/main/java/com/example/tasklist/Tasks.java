package com.example.tasklist;

public class Tasks {
    public String task, desc;

    public String getTask() {
        return task;
    }

    public String getDesc() {
        return desc;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    Tasks(String task, String desc){
        this.desc = desc;
        this.task =task;
    }
}
