package com.example.tasklist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;


public class addActivity extends AppCompatActivity {

    private Button saveBtn;
    private TextView name, desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        saveBtn = findViewById(R.id.add_task_btn);
        name = findViewById(R.id.add_task_name);
        desc = findViewById(R.id.add_task_desc);


        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taskName = name.getText().toString();
                String taskDesc = desc.getText().toString();

                Intent returnIntent = new Intent();
                returnIntent.putExtra("task_name", taskName);
                returnIntent.putExtra("task_desc", taskDesc);
                setResult(RESULT_OK, returnIntent);
                finish();
            }
        });
    }
}