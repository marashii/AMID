package com.example.tasklist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class EditTaskActivity extends AppCompatActivity {

    private EditText nameEditText, descEditText;
    private Button saveButton;
    private int taskPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_task);

        nameEditText = findViewById(R.id.edit_task_name);
        descEditText = findViewById(R.id.edit_task_desc);
        saveButton = findViewById(R.id.edit_task_btn);

        Intent intent = getIntent();
        taskPosition = intent.getIntExtra("task_position", -1);
        String taskName = intent.getStringExtra("task_name");
        String taskDesc = intent.getStringExtra("task_desc");

        nameEditText.setText(taskName);
        descEditText.setText(taskDesc);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String updatedName = nameEditText.getText().toString();
                String updatedDesc = descEditText.getText().toString();

                Intent returnIntent = new Intent();
                returnIntent.putExtra("updated_name", updatedName);
                returnIntent.putExtra("updated_desc", updatedDesc);
                returnIntent.putExtra("task_position", taskPosition);
                setResult(RESULT_OK, returnIntent);
                finish();
            }
        });
    }
}
