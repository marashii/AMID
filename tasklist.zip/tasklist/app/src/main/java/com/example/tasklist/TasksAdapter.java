package com.example.tasklist;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TasksAdapter extends RecyclerView.Adapter<TasksAdapter.TasksViewHolder> {

    private final ArrayList<Tasks> tasks;
    private final OnTaskListener onTaskListener; // Interfejs do obsługi kliknięć

    public TasksAdapter(ArrayList<Tasks> tasks, OnTaskListener onTaskListener) {
        this.tasks = tasks;
        this.onTaskListener = onTaskListener;
    }

    @NonNull
    @Override
    public TasksViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_item, parent, false);
        return new TasksViewHolder(view, onTaskListener);
    }

    @Override
    public void onBindViewHolder(@NonNull TasksViewHolder holder, int position) {
        Tasks task = tasks.get(position);
        holder.taskName.setText(task.getTask());
        holder.taskDesc.setText(task.getDesc());
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public static class TasksViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView taskName, taskDesc;
        OnTaskListener onTaskListener;

        public TasksViewHolder(@NonNull View itemView, OnTaskListener onTaskListener) {
            super(itemView);
            taskName = itemView.findViewById(R.id.task_name);
            taskDesc = itemView.findViewById(R.id.task_desc);
            this.onTaskListener = onTaskListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            onTaskListener.onTaskClick(getAdapterPosition());
        }
    }

    public interface OnTaskListener {
        void onTaskClick(int position);
    }
}
